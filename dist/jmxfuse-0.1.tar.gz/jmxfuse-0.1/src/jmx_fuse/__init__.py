"""
    Expose JMX MBeans as a Fuse Filesystem
    
    @license: GPL
    @copyright: Alastair McCormack
    @author: Alastair McCormack
    @contact: alastair@mcc-net.co.uk
"""